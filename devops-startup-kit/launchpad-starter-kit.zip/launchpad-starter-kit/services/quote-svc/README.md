# quote-svc

Sample service for the Launchpad starter kit. Current version: v1.2.0.
See app.py for endpoints and configuration.
