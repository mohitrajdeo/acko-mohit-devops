"""quote-svc: a sample Acko service for the Launchpad starter kit.

Bike insurance quotes. GET /quote?bike_cc=150&rider_age=30
GET /health    200 when the service is healthy
GET /version   the running version

Configuration (environment variables):
  PORT          port to listen on (default 8080)
  APP_ENV       environment name, for example staging or prod
  DB_PASSWORD   a secret; the service is unhealthy without it
"""
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

SERVICE = "quote-svc"
VERSION = "v1.2.0"
PORT = int(os.environ.get("PORT", "8080"))
POLICIES = {
    "P1001": {"id": "P1001", "holder": "Asha Rao", "product": "car", "status": "active"},
    "P1002": {"id": "P1002", "holder": "Vikram Shah", "product": "health", "status": "active"},
    "P1003": {"id": "P1003", "holder": "Neha Iyer", "product": "bike", "status": "lapsed"},
}


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body):
        data = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):
        print(f"{SERVICE} {VERSION} {self.command} {self.path}", flush=True)

    def do_GET(self):
        u = urlparse(self.path)
        path = u.path
        if path == "/health":
            # v1.2.0: a startup step that never completes, so this version never becomes healthy.
            return self._send(503, {"status": "starting", "detail": "warming cache"})
        if path == "/version":
            return self._send(200, {"service": SERVICE, "version": VERSION, "env": os.environ.get("APP_ENV", "unknown")})
        if path == "/quote":
            q = parse_qs(u.query)
            try:
                cc = int(q.get("bike_cc", ["150"])[0]); age = int(q.get("rider_age", ["30"])[0])
            except ValueError:
                return self._send(400, {"error": "bike_cc and rider_age must be whole numbers"})
            premium = 1200 + cc * 4
            if age >= 25:
                premium = int(premium * 0.9)  # v1.1.0: 10% discount for riders aged 25 or over
            return self._send(200, {"bike_cc": cc, "rider_age": age, "annual_premium_inr": premium})
        return self._send(404, {"error": "not found"})


if __name__ == "__main__":
    secret_state = "set" if os.environ.get("DB_PASSWORD") else "NOT SET"
    print(f"{SERVICE} {VERSION} starting on port {PORT}, APP_ENV={os.environ.get('APP_ENV', 'unknown')}, DB_PASSWORD is {secret_state}", flush=True)
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
