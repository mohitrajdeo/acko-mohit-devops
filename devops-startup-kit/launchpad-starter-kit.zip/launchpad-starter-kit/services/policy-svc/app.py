"""policy-svc: a sample Acko service for the Launchpad starter kit.

Insurance policies. GET /policies/<id> and GET /policies?holder=<name>
GET /health    200 when the service is healthy
GET /version   the running version

Configuration (environment variables):
  PORT          port to listen on (default 8080)
  APP_ENV       environment name, for example staging or prod
  DB_PASSWORD   a secret; the service is unhealthy without it
"""
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

SERVICE = "policy-svc"
VERSION = "v1.2.0"
PORT = int(os.environ.get("PORT", "8080"))
POLICIES = {
    "P1001": {"id": "P1001", "holder": "Asha Rao", "product": "car", "status": "active"},
    "P1002": {"id": "P1002", "holder": "Vikram Shah", "product": "health", "status": "active"},
    "P1003": {"id": "P1003", "holder": "Neha Iyer", "product": "bike", "status": "lapsed"},
}


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body):
        data = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):
        print(f"{SERVICE} {VERSION} {self.command} {self.path}", flush=True)

    def do_GET(self):
        u = urlparse(self.path)
        path = u.path
        if path == "/health":
            # v1.2.0: a startup step that never completes, so this version never becomes healthy.
            return self._send(503, {"status": "starting", "detail": "warming cache"})
        if path == "/version":
            return self._send(200, {"service": SERVICE, "version": VERSION, "env": os.environ.get("APP_ENV", "unknown")})
        if path.startswith("/policies/"):
            pid = path.rsplit("/", 1)[1]
            p = POLICIES.get(pid)
            return self._send(200, p) if p else self._send(404, {"error": "policy not found"})
        if path == "/policies":
            holder = parse_qs(u.query).get("holder", [""])[0].lower()
            return self._send(200, [p for p in POLICIES.values() if holder in p["holder"].lower()])  # v1.1.0: search by holder
        return self._send(404, {"error": "not found"})


if __name__ == "__main__":
    secret_state = "set" if os.environ.get("DB_PASSWORD") else "NOT SET"
    print(f"{SERVICE} {VERSION} starting on port {PORT}, APP_ENV={os.environ.get('APP_ENV', 'unknown')}, DB_PASSWORD is {secret_state}", flush=True)
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
